import streamlit as st
import requests

# 1. Page Configuration & Enhancements
st.set_page_config(
    page_title="OneDrive Knowledge Assistant",
    page_icon="☁️",
    layout="centered"
)

st.title("☁️ OneDrive Knowledge Assistant")
st.caption("Chat with your OneDrive documents, search files, and generate Meeting Minutes.")

# 2. Sidebar Features
with st.sidebar:
    st.header("⚙️ Controls & Info")
    st.markdown(
        "Use this assistant to find folders, search file content, "
        "or automatically summarize meeting notes into formatted Word documents."
    )
    
    st.divider()
    
    # Feature: Clear Chat History button
    if st.button("🗑️ Clear Chat History", use_container_width=True):
        st.session_state.messages = [
            {"role": "assistant", "content": "Hello! I am your OneDrive assistant. How can I help you today?"}
        ]
        st.rerun()
        
    st.divider()
    st.markdown("**Status Tracker**")
    st.success("UI Running")
    st.info("Ensure Flask Backend is running on port 5000")

# 3. Initialize Chat History
if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hello! I am your OneDrive assistant. How can I help you today?"}
    ]

# 4. Display Chat Messages
for message in st.session_state.messages:
    # Streamlit's native chat UI handles user vs assistant styling automatically
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# 5. Chat Input & Backend Communication
if prompt := st.chat_input("Ask about your files or request a MOM summary..."):
    
    # Add user message to UI and session state
    st.chat_message("user").markdown(prompt)
    st.session_state.messages.append({"role": "user", "content": prompt})

    # Display assistant response with a loading spinner
    with st.chat_message("assistant"):
        with st.spinner("Searching OneDrive & Thinking..."):
            try:
                # Call your existing Flask backend
                response = requests.post(
                    'http://127.0.0.1:5000/ask',
                    json={'message': prompt},
                    timeout=120 # 2-minute timeout for heavy document processing
                )
                
                if response.status_code == 200:
                    data = response.json()
                    if "error" in data:
                        reply = f"🚨 **Error:** {data['error']}"
                    else:
                        reply = data.get("response", "No response received.")
                else:
                    reply = f"🚨 **Server Error:** {response.status_code} - {response.text}"
                    
            except requests.exceptions.ConnectionError:
                reply = "🚨 **Connection Error:** Could not connect to the backend. Please ensure your Python Flask server (`app.py`) is running."
            except requests.exceptions.Timeout:
                reply = "⏳ **Timeout:** The server took too long to process the document."
            except Exception as e:
                reply = f"🚨 **Unexpected Error:** {str(e)}"
            
            # Render the response (Markdown is natively supported!)
            st.markdown(reply)
    
    # Save assistant response to history
    st.session_state.messages.append({"role": "assistant", "content": reply})