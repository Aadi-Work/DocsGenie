import os
import json
import requests
import msal
from docx import Document
import dotenv

dotenv.load_dotenv()

# LangChain Imports
from langchain_openai import ChatOpenAI, AzureChatOpenAI
from langchain_ollama import ChatOllama
from langchain_google_genai import ChatGoogleGenerativeAI
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import tool
from langchain.agents import create_agent
# ==========================================
# CONFIGURATION & CREDENTIALS
# ==========================================

MODEL_PROVIDER = "gemini"  # Options: "openai", "azure", "ollama", "gemini"

# Graph API App Settings
CLIENT_ID = os.getenv("MS_CLIENT_ID", "2194a676-0580-4882-a21c-d7d4d0a8966c")
AUTHORITY = 'https://login.microsoftonline.com/common'
SCOPES = ['Files.ReadWrite.All', 'User.Read']
GRAPH_ENDPOINT = 'https://graph.microsoft.com/v1.0'

# ==========================================
# CORE SERVICES
# ==========================================

def get_llm():
    """Returns the LLM instance based on the chosen provider."""
    if MODEL_PROVIDER == "gemini":
        # Requires GOOGLE_API_KEY environment variable
        return ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0)
        
    elif MODEL_PROVIDER == "openai":
        # Requires OPENAI_API_KEY environment variable
        return ChatOpenAI(model="gpt-4o", temperature=0)
        
    elif MODEL_PROVIDER == "azure":
        # Requires AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, and AZURE_OPENAI_DEPLOYMENT_NAME
        return AzureChatOpenAI(
            azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
            api_version="2024-05-01-preview",
            temperature=0
        )
        
    elif MODEL_PROVIDER == "ollama":
        # Requires Ollama running locally (default endpoint http://localhost:11434)
        return ChatOllama(model="llama3.1", temperature=0)
        
    else:
        raise ValueError(f"Unknown MODEL_PROVIDER: {MODEL_PROVIDER}")

def get_graph_headers():
    """Authenticates using MSAL Device Code Flow and returns Graph API headers."""
    app = msal.PublicClientApplication(CLIENT_ID, authority=AUTHORITY)
    accounts = app.get_accounts()
    
    # Try silent auth first using cached tokens
    result = app.acquire_token_silent(SCOPES, account=accounts[0]) if accounts else None
    
    # Fallback to interactive device code flow
    if not result:
        print("No cached token. Initiating Device Code Flow...")
        flow = app.initiate_device_flow(scopes=SCOPES)
        if "user_code" not in flow:
            raise ValueError(f"Failed to create device flow. Error: {flow}")
            
        print(flow["message"]) # Prompts user to open browser and enter code
        result = app.acquire_token_by_device_flow(flow)
        
    if "access_token" in result:
        return {
            'Authorization': f'Bearer {result["access_token"]}',
            'Content-Type': 'application/json'
        }
    else:
        raise Exception(f"Authentication failed: {result.get('error_description')}")

# ==========================================
# AI AGENT TOOLS (Graph API Interactions)
# ==========================================

@tool
def search_onedrive(query: str) -> str:
    """Searches the user's OneDrive for files matching the query and returns their IDs and names."""
    headers = get_graph_headers()
    search_url = f"{GRAPH_ENDPOINT}/me/drive/root/search(q='{query}')"
    response = requests.get(search_url, headers=headers)
    
    if response.status_code == 200:
        items = response.json().get('value', [])
        if not items:
            return "No files found matching the query."
        return json.dumps([{"name": i['name'], "id": i['id']} for i in items])
    return f"Error searching: {response.text}"

@tool
def download_and_read_text(file_id: str) -> str:
    """Downloads a file by ID from OneDrive and extracts its text (supports .txt and .docx)."""
    headers = get_graph_headers()
    download_url = f"{GRAPH_ENDPOINT}/me/drive/items/{file_id}/content"
    response = requests.get(download_url, headers=headers)
    
    if response.status_code != 200:
        return f"Failed to download file: {response.text}"
        
    temp_path = f"temp_{file_id}"
    with open(temp_path, "wb") as f:
        f.write(response.content)
    
    try:
        doc = Document(temp_path)
        text = "\n".join([paragraph.text for paragraph in doc.paragraphs])
    except:
        with open(temp_path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)
            
    return text

@tool
def update_excel_file(file_id: str, worksheet_name: str, values: list) -> str:
    """Updates an Excel file directly via Microsoft Graph without downloading it."""
    headers = get_graph_headers()
    url = f"{GRAPH_ENDPOINT}/me/drive/items/{file_id}/workbook/worksheets/{worksheet_name}/range(address='A1:C1')/insert"
    
    payload = {
        "shift": "Down", 
        "values": [values] 
    }
    
    response = requests.post(url, headers=headers, json=payload)
    if response.status_code in [200, 201]:
        return "Excel file updated successfully."
    return f"Failed to update Excel: {response.text}"

@tool
def upload_new_document(filename: str, content: str) -> str:
    """Creates a new Word document from the provided content and uploads it to OneDrive root."""
    doc = Document()
    doc.add_paragraph(content)
    local_path = f"temp_{filename}"
    doc.save(local_path)
    
    headers = get_graph_headers()
    headers.pop('Content-Type', None) # Remove for binary upload
    
    url = f"{GRAPH_ENDPOINT}/me/drive/root:/{filename}:/content"
    with open(local_path, 'rb') as f:
        response = requests.put(url, headers=headers, data=f)
    
    if os.path.exists(local_path):
        os.remove(local_path)
    
    if response.status_code in [200, 201]:
        return f"Successfully uploaded {filename} to OneDrive."
    return f"Failed to upload: {response.text}"

# ==========================================
# AGENT ORCHESTRATION
# ==========================================

# Create the checkpointer once outside the function so it persists across calls
memory = MemorySaver()


# Create the checkpointer once outside the function so it persists across calls
memory = MemorySaver()

def execute_user_prompt(user_prompt: str, thread_id: str = "workspace_session_1"):
    """Initializes the modern LangGraph Agent with memory and feeds it the prompt."""
    
    llm = get_llm()
    tools = [search_onedrive, download_and_read_text, update_excel_file, upload_new_document]
    
    system_prompt = (
        "You are an intelligent Microsoft 365 Workspace Assistant. "
        "You have access to tools to search files, read them, update Excel, and generate new Word documents. "
        "If a user asks to generate a document from a template, search for the template, read it, "
        "determine what variables are missing based on the user's prompt, and ask the user for the missing "
        "information before generating and uploading the final document. Always ensure file IDs are used exactly as retrieved."
    )
    
    # Use create_agent and the new 'prompt' keyword
    agent = create_agent(llm, tools, system_prompt=system_prompt, checkpointer=memory)
    
    print(f"\n[Processing Request]: {user_prompt}...\n")
    
    # Pass the configurable thread_id when invoking the agent
    config = {"configurable": {"thread_id": thread_id}}
    response = agent.invoke({"messages": [("user", user_prompt)]}, config)
    
    # Extract and print the final assistant response
    final_output = response["messages"][-1].content
    print(f"\n[Assistant]: {final_output}\n")
# ==========================================
# ENTRY POINT
# ==========================================

if __name__ == "__main__":
    # Before running, ensure environment variables are set in your terminal:
    # export MS_CLIENT_ID="your-azure-app-client-id"
    GOOGLE_API_KEY="AQ.Ab8RN6IoOfe0MUGfZZML2MXJKSF_1wHRGG9jvrCEo1o6QM9B4g"
    
    print("Welcome to the AI Workspace Assistant!")
    while True:
        user_input = input("\nWhat would you like me to do? (Type 'exit' to quit)\n> ")
        if user_input.lower() in ['exit', 'quit']:
            break
        execute_user_prompt(user_input)