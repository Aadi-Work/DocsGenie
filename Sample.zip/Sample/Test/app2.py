import streamlit as st
import requests

# ==============================================================================
# CONFIGURATION
# ==============================================================================
st.set_page_config(page_title="OneDrive GenAI Agent", page_icon="☁️", layout="wide")

# Point this to your FastAPI server address
BASE_URL = "http://localhost:8000"

st.title("☁️ OneDrive GenAI Assistant")
st.markdown("Interact with your OneDrive documents, search for files, and generate Meeting Minutes.")

# ==============================================================================
# SIDEBAR CONFIGURATION
# ==============================================================================
with st.sidebar:
    st.header("Settings")
    api_key = st.text_input("Gemini API Key (Optional)", type="password", help="Overrides backend key if provided")
    project_name = st.text_input("Default Project Name", value="Demo Project")
    
    st.divider()
    st.caption(f"Backend URL: `{BASE_URL}`")

    # Check backend health
    try:
        requests.get(f"{BASE_URL}/docs", timeout=2)
        st.success("🟢 Backend is online")
    except requests.exceptions.RequestException:
        st.error("🔴 Backend is offline. Please start FastAPI.")

# ==============================================================================
# TABS SETUP
# ==============================================================================
tab_chat, tab_search, tab_mom, tab_system = st.tabs([
    "💬 Agent Chat", 
    "🔍 Document Search", 
    "📝 Generate MOM", 
    "⚙️ System Sync"
])

# ------------------------------------------------------------------------------
# TAB 1: AGENT CHAT
# ------------------------------------------------------------------------------
with tab_chat:
    st.subheader("Chat with the Knowledge Agent")
    
    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Display chat messages from history on app rerun
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # React to user input
    if prompt := st.chat_input("Ask about your latest documents or ask me to generate a MOM..."):
        # Display user message
        st.chat_message("user").markdown(prompt)
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})

        # Send to API
        with st.chat_message("assistant"):
            with st.spinner("Agent is thinking..."):
                payload = {
                    "user_input": prompt,
                    "project_name": project_name,
                    "output_name": "final_minutes.docx"
                }
                if api_key:
                    payload["api_key"] = api_key
                
                try:
                    res = requests.post(f"{BASE_URL}/api/chat", json=payload)
                    res.raise_for_status()
                    reply = res.json().get("response", "No response received.")
                    st.markdown(reply)
                    st.session_state.messages.append({"role": "assistant", "content": reply})
                except Exception as e:
                    st.error(f"API Error: {e}")

# ------------------------------------------------------------------------------
# TAB 2: DOCUMENT SEARCH
# ------------------------------------------------------------------------------
with tab_search:
    st.subheader("Manual Vector Search")
    
    search_mode = st.radio("Search Mode", ["Hybrid (Filename + Content)", "Content Only", "Folder Path"], horizontal=True)
    search_query = st.text_input("Enter search query...")
    find_latest = st.checkbox("Find latest document only (Hybrid mode only)")
    
    if st.button("Search", type="primary", use_container_width=True):
        if not search_query:
            st.warning("Please enter a search query.")
        else:
            with st.spinner("Searching vector database..."):
                try:
                    if search_mode == "Folder Path":
                        res = requests.post(f"{BASE_URL}/api/search/folder", json={"query": search_query})
                    elif search_mode == "Content Only":
                        res = requests.post(f"{BASE_URL}/api/search/content", json={"query": search_query})
                    else:
                        res = requests.post(f"{BASE_URL}/api/search/hybrid", json={"query": search_query, "find_latest_only": find_latest})
                    
                    st.json(res.json())
                except Exception as e:
                    st.error(f"Search failed: {e}")

# ------------------------------------------------------------------------------
# TAB 3: MOM GENERATOR
# ------------------------------------------------------------------------------
with tab_mom:
    st.subheader("Generate Meeting Minutes")
    st.write("Manually trigger the MOM extraction pipeline for a specific file.")
    
    with st.form("mom_form"):
        col1, col2 = st.columns(2)
        with col1:
            mom_file_id = st.text_input("File ID", help="The OneDrive Graph API File ID")
            mom_file_name = st.text_input("File Name", help="e.g., notes.txt")
        with col2:
            mom_project = st.text_input("Project Name", value=project_name)
            mom_date = st.text_input("Meeting Date (Optional)", placeholder="YYYY-MM-DD")
        
        submit_mom = st.form_submit_button("Extract & Generate Word Document", type="primary", use_container_width=True)
        
    if submit_mom:
        if not mom_file_id or not mom_file_name:
            st.error("File ID and File Name are required.")
        else:
            with st.spinner("Extracting action items and rendering document..."):
                payload = {
                    "file_id": mom_file_id,
                    "file_name": mom_file_name,
                    "project_name": mom_project,
                    "date": mom_date if mom_date else None
                }
                try:
                    res = requests.post(f"{BASE_URL}/api/mom/generate", json=payload)
                    st.success("Pipeline executed successfully!")
                    st.json(res.json())
                except Exception as e:
                    st.error(f"Generation failed: {e}")

# ------------------------------------------------------------------------------
# TAB 4: SYSTEM SYNC
# ------------------------------------------------------------------------------
with tab_system:
    st.subheader("Database Synchronization")
    st.write("Sync your OneDrive files with the local ChromaDB vector store.")
    
    force_resync = st.checkbox("Force Full Resync (Wipe existing vector database)")
    
    if st.button("Trigger Sync Now", type="primary"):
        with st.spinner("Syncing with OneDrive... This may take a while depending on your file count."):
            try:
                # We use query params for force_resync as defined in your FastAPI endpoint
                res = requests.post(f"{BASE_URL}/api/sync?force_resync={str(force_resync).lower()}")
                if res.status_code == 200:
                    st.success("Sync complete!")
                    st.json(res.json())
                else:
                    st.error(f"Sync returned status {res.status_code}: {res.text}")
            except Exception as e:
                st.error(f"Sync request failed: {e}")